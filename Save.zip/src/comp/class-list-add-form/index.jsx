import { useNavigate } from "react-router-dom"
import "./index.css"
import { randomStr } from "../../utils"
import { useRef } from "react"

function ClassListAddForm({ setClasses }) {
  const nav = useNavigate()
  const nameInput = useRef()

  return (
    <form className="add-class-form" onSubmit={e => {
      e.preventDefault()
      setClasses(old => {
        var id = randomStr(10)

        if (old[id]) {
          return old
        } else {
          old[id] = {
            name: nameInput.current?.value,
            students: []
          }
          nameInput.current.value = ""
          nav(`/class/${id}`)
          return { ...old }
        }
      })
    }}>
      <input type="text" placeholder="Klassenname..." ref={nameInput} />
      <button type="submit">
        <svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 -960 960 960" width="24"><path d="M440-440H200v-80h240v-240h80v240h240v80H520v240h-80v-240Z" /></svg>
        Hinzufügen
      </button>
    </form>
  )
}

export default ClassListAddForm