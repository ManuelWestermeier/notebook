import "./index.css"
import ClassListItem from "./class-list-item"

function ClassList({ classes = {}, setClasses }) {
    const deleteItem = (e, key) => {
        e.preventDefault()
        if (!confirm(`Wollen sie die Klasse ${classes[key].name} wirklich löschen?`))
            return
        setClasses(old => {
            delete old[key]
            return { ...old }
        })
    }

    return (
        <div className="class-list">
            {Object.keys(classes).map(key => {
                return <ClassListItem
                    key={key}
                    id={key}
                    deleteItem={deleteItem}
                    name={classes[key].name}
                    setClasses={setClasses}
                />
            })}
        </div>
    )
}

export default ClassList