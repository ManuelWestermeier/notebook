export const defaultClasses = {
    test: {
        name: "Test",
        students: [{
            name: "Test Schüler",
            notes: [{
                note: 3,
                isBig: false,
                day: new Date().toDateString()
            }, {
                note: 2,
                isBig: true,
                day: new Date().toDateString()
            }, {
                note: 4,
                isBig: false,
                day: new Date().toDateString()
            }],
            studentId: "dhjjd"
        }, {
            name: "Test Schüler 2",
            notes: [{
                note: 2,
                isBig: false,
                day: new Date().toDateString()
            }, {
                note: 1,
                isBig: true,
                day: new Date().toDateString()
            }, {
                note: 1,
                isBig: false,
                day: new Date().toDateString()
            }, {
                note: 1,
                isBig: false,
                day: new Date().toDateString()
            },],
            studentId: "dhjjd_"
        }]
    }
}