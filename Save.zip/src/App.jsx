import useLocalStorage from "use-local-storage"
import Home from "./pages/home"
import { Navigate, Route, Routes } from "react-router-dom"
import Class from "./pages/class"
import Student from "./pages/student"

function App() {
  const [classes, setClasses] = useLocalStorage("classes", {})

  return <Routes>
    <Route path="/" element={<Home classes={classes} setClasses={setClasses} />} />
    <Route path="/class/:id" element={<Class classes={classes} setClasses={setClasses} />} />
    <Route path="/class/:id/:studentId" element={<Student classes={classes} setClasses={setClasses} />} />
    <Route path="*" element={<Navigate replace to="/" />} />
  </Routes>
}

export default App