import { Navigate, Route, Routes } from "react-router-dom"
import { defaultClasses } from "./data/default-classes"
import useLocalStorage from "use-local-storage"
import Settings from "./pages/settings"
import { changeTheme } from "./utils"
import Student from "./pages/student"
import Class from "./pages/class"
import { useEffect } from "react"
import Home from "./pages/home"

const defaultTheme = window
  .matchMedia("(prefers-color-scheme: dark)")
  .matches ? "dark" : "light"

function App() {
  const [theme, setTheme] = useLocalStorage("theme", [
    defaultTheme,
    "rgb(0, 112, 224)"
  ])
  const [classes, setClasses] = useLocalStorage("classes", defaultClasses)

  useEffect(() => changeTheme(theme), [theme])

  return <Routes>
    <Route path="/" element={<Home classes={classes} setClasses={setClasses} />} />
    <Route path="/settings" element={<Settings theme={theme} setTheme={setTheme} />} />
    <Route path="/class/:id" element={<Class classes={classes} setClasses={setClasses} />} />
    <Route path="/class/:id/:studentId" element={<Student theme={theme[0]} classes={classes} setClasses={setClasses} />} />
    <Route path="*" element={<Navigate replace to="/" />} />
  </Routes>
}

export default App