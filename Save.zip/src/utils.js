export function randomStr(length) {

    var result = '';
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    const charactersLength = characters.length;
    var counter = 0;

    while (counter < length) {
        result += characters[Math.floor(Math.random() * charactersLength)];
        counter += 1;
    }

    return result;

}

export const changeTheme = (theme) => {

    const style = (x, y) => document.documentElement.style.setProperty(x, y)

    style("--b", theme[0] == "light" ? "rgb(239, 239, 239)" : "rgb(32, 32, 32)")
    style("--c", theme[0] == "light" ? "rgb(32, 32, 32)" : "rgb(239, 239, 239)")
    style("--p", theme[0] == "light" ? "rgb(230, 230, 230)" : "rgb(55, 55, 55)")
    style("--a", theme[1])

}

export async function registerServiceWorker() {
    if ("serviceWorker" in navigator) {
        try {
            const registration = await navigator.serviceWorker.register("/service-worker.js", {
                scope: "/",
            });
            if (registration.installing) {
                console.log("Service worker installing");
            } else if (registration.waiting) {
                console.log("Service worker installed");
            } else if (registration.active) {
                console.log("Service worker active");
            }
        } catch (error) { }
    }
};

//disable fetch
var f = window.fetch
window.fetch = (url, data) => {
    alert("fetch : " + url);
    return f(url, data)
}
//disable contextmenu
window.oncontextmenu = e => e.preventDefault()