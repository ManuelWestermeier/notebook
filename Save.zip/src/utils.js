export function randomStr(length) {

    var result = '';
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    const charactersLength = characters.length;
    var counter = 0;

    while (counter < length) {
        result += characters[Math.floor(Math.random() * charactersLength)];
        counter += 1;
    }

    return result;

}