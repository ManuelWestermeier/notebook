function Settings({ theme, setTheme }) {
    const nextToggleTheme = theme[0] == "light" ? "dark" : "light"

    return (
        <fieldset>
            <legend>
                <h2>Einstellungen</h2>
            </legend>
            <div style={{ display: "flex", alignItems: "center" }}>
                <span>
                    Farbthema : [{theme[0]}]
                </span>
                <button
                    onClick={e => {
                        setTheme(old => {
                            return [nextToggleTheme, old[1]]
                        })
                    }}
                    style={{ marginLeft: "auto" }}
                >
                    auf [{nextToggleTheme}] setzen
                </button>
            </div>
            <div style={{ display: "flex", alignItems: "center" }}>
                <span>
                    Akzent : <span style={{ backgroundColor: theme[1] }}>
                        [{theme[1]}]
                    </span>
                </span>
                <input
                    type='color'
                    value={theme[1]}
                    onChange={e => {
                        setTheme(old => {
                            return [old[0], e.target.value]
                        })
                    }}
                    style={{ marginLeft: "auto" }}
                >
                </input>
            </div>
        </fieldset>
    )
}

export default Settings