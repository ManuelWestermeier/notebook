import ClassList from "../comp/class-list"
import ClassListAddForm from "../comp/class-list-add-form"

function Home({ classes, setClasses }) {
    return <>
        <ClassList classes={classes} setClasses={setClasses} />
        <fieldset>
            <legend><b>Klasse hinzufügen</b></legend>
            <ClassListAddForm setClasses={setClasses} />
        </fieldset>
    </>
}

export default Home