import { useState } from "react"
import NotenList from "./noten-list"
import { Line } from '@ant-design/charts'

function Statistik({ student, setClasses, studentId, id, theme }) {
    const [see, setSee] = useState(student.notes.length < 2)
    return (
        <fieldset>
            <legend onClick={e => setSee(see => !see)} style={{ cursor: "pointer" }}><b>Statistik</b></legend>
            <div>
                {student.notes.length >= 2 && <Line
                    height={300}
                    theme={theme}
                    data={student.notes.map(({ note }, i) => { return { Note: note, x: i + 1 } })}
                    xField="x"
                    yField="Note"
                />}
            </div>
            <div onClick={e => setSee(see => !see)} style={{ cursor: "pointer" }}>{see ? "Weniger..." : "Mehr..."}</div>
            <div style={{ display: see ? "" : "none"}} className="notes-vue">
                <NotenList notes={student.notes} setNotes={newNotes => {
                    setClasses(old => {
                        old[id].students = old[id].students.map((s, i) => {
                            if (s.studentId != studentId) {
                                return s
                            } else {
                                return {
                                    ...student,
                                    notes: newNotes
                                }
                            }
                        })
                        return { ...old }
                    })
                }} />
            </div>
        </fieldset>
    )
}

export default Statistik