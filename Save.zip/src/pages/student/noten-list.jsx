const colors = ["gold", "yellow", "yellowgreen", "orange", "red", "grey"]

function noteToColor(note) {
    return colors[Math.floor(note) - 1] ?? "transparent"
}

function NotenList({ notes, setNotes }) {
    return (
        <div className="class-list">
            {notes.map(({ isBig, note, day }, i) => {
                return <div key={i} className="class">
                    <span style={{ backgroundImage: `radial-gradient(${noteToColor(note)},  transparent)` }}>{note}</span>
                    <span>{isBig ? "Kleine Note" : "Große Note"}</span>
                    <a href={`https://google.com/search?q=${day}`}>{day}</a>
                    <button onClick={e => {
                        //delete
                        setNotes(notes.filter((n, index) => index != i))
                    }}>
                        <svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 -960 960 960" width="24"><path d="M280-120q-33 0-56.5-23.5T200-200v-520h-40v-80h200v-40h240v40h200v80h-40v520q0 33-23.5 56.5T680-120H280Zm400-600H280v520h400v-520ZM360-280h80v-360h-80v360Zm160 0h80v-360h-80v360ZM280-720v520-520Z" /></svg>
                    </button>
                </div>
            })}
        </div>
    )
}

export default NotenList