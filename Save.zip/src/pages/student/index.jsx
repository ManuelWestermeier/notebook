import { Link, Navigate, useParams } from "react-router-dom"
import NoteAddForm from "./note-add-form"
import Statistik from "./statistik"
import "./index.css"

function durchschnitt(items = []) {

    if (items.length == 0) {
        return 0
    }

    var _durschschitt = 0

    items.forEach(n => {
        _durschschitt += n.note
    })

    return _durschschitt / items.length

}

function getMainNote(notes) {
    if (notes.length == 0) {
        return "noch keine Noten"
    }

    var mNote = durchschnitt(notes.filter(n => !n.isBig))
    var sNote = durchschnitt(notes.filter(n => n.isBig))

    if (mNote == 0) {
        return (sNote || 1).toFixed(2)
    }
    else if (sNote == 0) {
        return (mNote || 1).toFixed(2)
    }
    else {
        return ((sNote * 2 + mNote) / 3).toFixed(2)
    }
}

function floorMainNote(note = 0) {
    for (let index = 1; index < 6; index++) {
        if (note < index + 0.51) {
            return index
        }
    }
}

function Student({ classes, setClasses, theme }) {
    const { id, studentId } = useParams()
    const student = classes?.[id]?.students?.filter?.(std => std.studentId == studentId)?.[0]

    if (!student) {
        return <Navigate to="/" replace />
    }

    const mainNote = getMainNote(student.notes)

    const addNote = ([note, isBig]) => {
        setClasses(old => {
            old[id].students = old[id].students.map((s, i) => {
                if (s.studentId != studentId) {
                    return s
                } else {
                    return {
                        ...student,
                        notes: [...old[id].students[i].notes, { note, isBig, day: new Date().toLocaleDateString() }]
                    }
                }
            })
            return { ...old }
        })
    }

    return (
        <fieldset>
            <legend>
                <h2>
                    <Link to={`/class/${id}`}>{classes[id].name}</Link> {student?.name}
                </h2>
            </legend>
            <fieldset>
                <legend><b>Noten (insgesamt {student.notes.length})</b></legend>
                <p><b>Note : {mainNote} ~ {floorMainNote(mainNote)}</b></p>
                <p style={{ color: mainNote > 4.5 ? "red" : "yellowgreen" }}>
                    <i>{mainNote > 4.5 ? "Ist gefährdet." : "Ist nicht gefährdet."}</i>
                </p>
                <p>Kleine Note {"=>"} {durchschnitt(student.notes.filter(n => !n.isBig)).toFixed(2)} von {student.notes.filter(n => !n.isBig).length} Noten</p>
                <p>Große Note {"=>"} {durchschnitt(student.notes.filter(n => n.isBig)).toFixed(2)} von {student.notes.filter(n => n.isBig).length} Noten</p>
            </fieldset>
            <Statistik student={student} setClasses={setClasses} id={id} theme={theme} studentId={studentId} />
            <NoteAddForm addNote={addNote} />
        </fieldset>
    )
}

export default Student