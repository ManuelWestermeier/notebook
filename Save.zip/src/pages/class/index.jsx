import { Link, Navigate, useParams } from "react-router-dom"
import AddStudentForm from "./add-student-form"
import StudentList from "./student-list"
import { randomStr } from "../../utils"

const legendStyle = {
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between"
}

function Class({ classes, setClasses }) {
    const { id } = useParams()
    const actuaClass = classes[id]

    if (!actuaClass) return <Navigate replace to="/" />

    const randomStudentIndex = Math.floor(actuaClass.students.length * Math.random())
    const randomStudentId = actuaClass.students[randomStudentIndex]?.studentId;
    const randomStudentIdLink = `/class/${id}/${randomStudentId ?? ""}`

    const addUser = name => {
        setClasses(old => {
            old[id].students = [{ name, notes: [], studentId: randomStr(10) }, ...old[id].students]
            return { ...old }
        })
    }

    return (
        <>
            <fieldset>
                <legend style={legendStyle}>
                    <h2>{actuaClass.name}</h2>
                    <Link style={{ marginLeft: `${innerWidth / 5}px` }} to={randomStudentIdLink}>
                        zufälligen Schüler auswählen
                    </Link>
                </legend>
                <StudentList
                    actuaClass={actuaClass}
                    id={id}
                    setClasses={setClasses}
                />
                <AddStudentForm addUser={addUser} />
            </fieldset>
        </>
    )
}

export default Class