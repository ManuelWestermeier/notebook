import { Link, Navigate, useParams } from "react-router-dom"
import AddStudentForm from "./add-student-form"
import { randomStr } from "../../utils"

function Class({ classes, setClasses }) {
    const { id } = useParams()
    const actuaClass = classes[id]

    if (!actuaClass) return <Navigate replace to="/" />

    const studentList = <div className="class-list">
        {actuaClass.students.sort((a, b) => {
            return a.notes.length - b.notes.length
        }).map(({ name, notes = [], studentId }) => {
            return <Link
                key={studentId}
                to={`/class/${id}/${studentId}`} className="class" title={`(${notes.filter(n => !n.isBig).length} kleine) (${notes.filter(n => n.isBig).length} große) Noten`}
            >
                <span>
                    {name}
                </span>
                <span style={{ marginLeft: "auto" }} className="u-none">
                    {notes.length} Noten
                </span>
                <button type="button" onClick={e => {
                    //delete
                    e.preventDefault()
                    if (!confirm(`Wollen sie wirklich ${name} löschen?`))
                        return
                    setClasses(old => {
                        old[id].students = old[id].students.filter(s => s.studentId != studentId)
                        return { ...old }
                    })
                }}>
                    <svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 -960 960 960" width="24"><path d="M280-120q-33 0-56.5-23.5T200-200v-520h-40v-80h200v-40h240v40h200v80h-40v520q0 33-23.5 56.5T680-120H280Zm400-600H280v520h400v-520ZM360-280h80v-360h-80v360Zm160 0h80v-360h-80v360ZM280-720v520-520Z" /></svg>
                </button>
            </Link>
        })}
    </div>

    return (
        <>
            <fieldset>
                <legend style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                    <h2>{actuaClass.name}</h2>
                    <Link style={{ marginLeft: "50px" }} to={`/class/${id}/${actuaClass.students[Math.floor(actuaClass.students.length * Math.random())].studentId}`}>
                        zufälligen Schüler auswählen
                    </Link>
                </legend>
                {studentList}
                <AddStudentForm addUser={name => {
                    setClasses(old => {
                        old[id].students = [{ name, notes: [], studentId: randomStr(10) }, ...old[id].students]
                        return { ...old }
                    })
                }} />
            </fieldset>
        </>
    )
}

export default Class