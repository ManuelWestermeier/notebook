import { Link } from "react-router-dom"

function StudentList({ actuaClass, setClasses, id }) {
    return (
        <div className="class-list">
            {actuaClass.students.sort((a, b) => {
                return a.notes.length - b.notes.length
            }).map(({ name, notes = [], studentId }) => {
                return <Link
                    key={studentId}
                    to={`/class/${id}/${studentId}`} className="class" title={`(${notes.filter(n => !n.isBig).length} kleine) (${notes.filter(n => n.isBig).length} große) Noten`}
                >
                    <span>
                        {name}
                    </span>
                    <span style={{ marginLeft: "auto" }} className="u-none">
                        {notes.length} Noten
                    </span>
                    <button type="button" onClick={e => {
                        //delete
                        e.preventDefault()
                        if (!confirm(`Wollen sie wirklich ${name} löschen?`))
                            return
                        setClasses(old => {
                            old[id].students = old[id].students.filter(s => s.studentId != studentId)
                            return { ...old }
                        })
                    }}>
                        <svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 -960 960 960" width="24"><path d="M280-120q-33 0-56.5-23.5T200-200v-520h-40v-80h200v-40h240v40h200v80h-40v520q0 33-23.5 56.5T680-120H280Zm400-600H280v520h400v-520ZM360-280h80v-360h-80v360Zm160 0h80v-360h-80v360ZM280-720v520-520Z" /></svg>
                    </button>
                </Link>
            })}
        </div>
    )
}

export default StudentList