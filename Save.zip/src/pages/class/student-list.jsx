import { Link } from "react-router-dom"
import StudentListItem from "./student-list-item"

function StudentList({ actuaClass, setClasses, id }) {
    return (
        <div className="class-list">
            {actuaClass.students.sort((a, b) => {
                return a.notes.length - b.notes.length
            }).map(({ name, notes = [], studentId }) => {
                return <StudentListItem key={studentId} name={name} notes={notes} studentId={studentId} id={id} setClasses={setClasses} />
            })}
        </div>
    )
}

export default StudentList